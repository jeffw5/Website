# INCOSE SEBoK Core Ontology - Usage Guide and Relationship Map

## Version 1.0 | February 2025

---

## Table of Contents

1. [Overview](#overview)
2. [Core Concept Hierarchy](#core-concept-hierarchy)
3. [Key Relationship Patterns](#key-relationship-patterns)
4. [Usage Scenarios](#usage-scenarios)
5. [Integration Patterns](#integration-patterns)
6. [SPARQL Query Examples](#sparql-query-examples)
7. [Alignment with Standards](#alignment-with-standards)

---

## Overview

This ontology captures the fundamental concepts from the SEBoK (Systems Engineering Body of Knowledge) v2.13 that are universally applicable across all systems engineering domains. It provides a semantic foundation for:

- **System Life Cycle Management**: From concept through retirement
- **Process Integration**: Connecting technical management, definition, realization, and deployment processes
- **Artifact Traceability**: Linking requirements, architectures, models, and other work products
- **Stakeholder Management**: Relating people, roles, and responsibilities to systems
- **Quality Assurance**: Tracking quality attributes and their relationships to systems

**Primary Standards Alignment:**
- ISO/IEC/IEEE 15288:2023 (System Life Cycle Processes)
- ISO/IEC/IEEE 24748-1:2024 (Life Cycle Management)
- INCOSE Systems Engineering Handbook v5.0

---

## Core Concept Hierarchy

### 1. System Concepts

```
System (top-level)
├── EngineeredSystem
│   ├── ProductSystem
│   ├── ServiceSystem
│   ├── EnterpriseSystem
│   └── SystemOfSystems
├── NaturalSystem
└── SocialSystem
```

**Key Properties:**
- Every system `hasContext` (SystemContext)
- Systems are `composedOf` / `partOf` other systems
- Systems `interactsWith` other systems
- Systems `dependsOn` other systems

### 2. Life Cycle Hierarchy

```
LifeCycle
├── LifeCycleModel
└── LifeCycleStage
    ├── ConceptStage
    ├── DevelopmentStage
    ├── ProductionStage
    ├── UtilizationStage
    ├── SupportStage
    └── RetirementStage
```

**Key Relationships:**
- Systems `hasLifeCycle` and `followsLifeCycleModel`
- Life cycles `hasStage` (multiple stages)
- Stages can `precedesStage` / `followsStage`
- Systems `usesDevelopmentApproach`

### 3. Process Hierarchy

```
Process
└── LifeCycleProcess
    ├── TechnicalManagementProcess
    │   ├── ProjectPlanning
    │   ├── ProjectAssessmentAndControl
    │   ├── DecisionManagement
    │   ├── RiskManagement
    │   ├── ConfigurationManagement
    │   ├── InformationManagement
    │   ├── RequirementsManagement
    │   ├── QualityManagement
    │   └── Measurement
    ├── SystemDefinitionProcess
    │   ├── BusinessOrMissionAnalysis
    │   ├── StakeholderNeedsDefinition
    │   ├── SystemRequirementsDefinition
    │   ├── SystemArchitectureDefinition
    │   └── SystemDetailedDesign
    ├── SystemRealizationProcess
    │   ├── SystemAnalysis
    │   ├── SystemImplementation
    │   ├── SystemIntegration
    │   └── SystemVerification
    └── SystemDeploymentProcess
        ├── SystemTransition
        ├── SystemValidation
        ├── SystemOperation
        ├── SystemMaintenance
        └── SystemDisposal
```

**Key Relationships:**
- Processes `appliedDuringStage` (specific life cycle stages)
- Processes `producesArtifact` and `consumesArtifact`
- Processes can `enablesProcess` other processes
- Processes `precedesProcess` in temporal/logical order
- Stakeholders `performsProcess`

### 4. Artifact Hierarchy

```
Artifact
├── Requirement
│   ├── StakeholderRequirement
│   └── SystemRequirement
│       ├── FunctionalRequirement
│       └── NonFunctionalRequirement
├── Architecture
│   ├── FunctionalArchitecture
│   ├── LogicalArchitecture
│   └── PhysicalArchitecture
├── Model
│   └── SystemModel
├── ConfigurationItem
├── ConfigurationBaseline
├── Plan
│   └── TechnicalPlan
└── Specification
    └── DesignSpecification
```

**Key Relationships:**
- Systems `hasRequirement` (Requirements)
- Requirements `derivedFrom` and `refinesRequirement` other requirements
- Requirements `allocatedTo` system elements
- Requirements `satisfiedBy` / systems `satisfiesRequirement`
- Requirements `tracesTo` other artifacts
- Requirements `expressedBy` stakeholders
- Systems `hasArchitecture`
- Models `representsSystem`
- Configuration items `hasBaseline`

### 5. Stakeholder Hierarchy

```
Stakeholder
├── SystemsEngineer
├── ProjectManager
├── SystemOwner
├── Operator
└── Customer
```

**Key Relationships:**
- Systems `hasStakeholder` / stakeholders `stakeholderIn` systems
- Stakeholders `hasRole`
- Stakeholders `memberOf` teams/organizations
- Stakeholders `performsProcess`
- Stakeholders `expressedBy` requirements

### 6. Quality Attribute Hierarchy

```
QualityAttribute
├── Reliability
├── Availability
├── Maintainability
├── Safety
├── Security
├── Resilience
├── Affordability
└── Usability
```

**Key Relationships:**
- Systems `hasQualityAttribute`
- Systems/requirements `constrainedBy` quality attributes

---

## Key Relationship Patterns

### Pattern 1: Requirements Flow

```turtle
:SystemX a incose:EngineeredSystem ;
    incose:hasStakeholder :Customer1 ;
    incose:hasRequirement :StakeholderReq1 .

:StakeholderReq1 a incose:StakeholderRequirement ;
    incose:expressedBy :Customer1 ;
    incose:requirementText "System shall process 1000 transactions/second" .

:SystemReq1 a incose:FunctionalRequirement ;
    incose:derivedFrom :StakeholderReq1 ;
    incose:allocatedTo :ProcessingSubsystem ;
    incose:verificationMethod "Performance testing" .

:ProcessingSubsystem incose:satisfiesRequirement :SystemReq1 .
```

### Pattern 2: Process Artifact Flow

```turtle
:ReqDefProcess a incose:SystemRequirementsDefinition ;
    incose:appliedDuringStage incose:ConceptStage ;
    incose:consumesArtifact :StakeholderReqs ;
    incose:producesArtifact :SystemReqs ;
    incose:enablesProcess :ArchDefProcess .

:ArchDefProcess a incose:SystemArchitectureDefinition ;
    incose:appliedDuringStage incose:DevelopmentStage ;
    incose:consumesArtifact :SystemReqs ;
    incose:producesArtifact :SystemArch .
```

### Pattern 3: Life Cycle Progression

```turtle
:MySystem a incose:ProductSystem ;
    incose:hasLifeCycle :MySystemLC ;
    incose:followsLifeCycleModel :IncrementalModel ;
    incose:usesDevelopmentApproach incose:AgileDevelopment .

:MySystemLC a incose:LifeCycle ;
    incose:hasStage :ConceptPhase, :DevelopPhase, :ProductionPhase .

:ConceptPhase a incose:ConceptStage ;
    incose:precedesStage :DevelopPhase ;
    incose:startDate "2025-01-01"^^xsd:dateTime .

:DevelopPhase a incose:DevelopmentStage ;
    incose:followsStage :ConceptPhase ;
    incose:precedesStage :ProductionPhase .
```

### Pattern 4: Architecture Realization

```turtle
:SystemX incose:hasArchitecture :FunctionalArch, :LogicalArch, :PhysicalArch .

:FunctionalArch a incose:FunctionalArchitecture ;
    incose:satisfiesRequirement :FunctionalReqs .

:LogicalArch a incose:LogicalArchitecture ;
    incose:realizesArchitecture :FunctionalArch .

:PhysicalArch a incose:PhysicalArchitecture ;
    incose:realizesArchitecture :LogicalArch .

:ActualSystem incose:realizesArchitecture :PhysicalArch .
```

### Pattern 5: Verification and Validation Chain

```turtle
:SystemReq1 incose:verifiedBy :VerificationTest1 .

:VerificationTest1 a incose:SystemVerification ;
    incose:verifies :SystemReq1 ;
    incose:appliedDuringStage incose:DevelopmentStage ;
    incose:status "Passed" .

:SystemX incose:validatedBy :ValidationActivity1 .

:ValidationActivity1 a incose:SystemValidation ;
    incose:validates :SystemX ;
    incose:appliedDuringStage incose:UtilizationStage ;
    incose:producesArtifact :ValidationReport .
```

### Pattern 6: System Decomposition

```turtle
:AircraftSystem a incose:ProductSystem ;
    incose:composedOf :PropulsionSubsystem, :AvionicsSubsystem, :StructureSubsystem .

:PropulsionSubsystem incose:partOf :AircraftSystem ;
    incose:interactsWith :AvionicsSubsystem ;
    incose:hasRequirement :PropulsionReqs .

:AvionicsSubsystem incose:partOf :AircraftSystem ;
    incose:dependsOn :PropulsionSubsystem .
```

### Pattern 7: Risk and Decision Management

```turtle
:SystemX incose:hasRisk :TechnicalRisk1 .

:TechnicalRisk1 incose:probability "0.3"^^xsd:decimal ;
    incose:severity "8"^^xsd:decimal ;
    incose:description "Integration complexity may delay schedule" .

:MitigationStrategy incose:mitigatesRisk :TechnicalRisk1 .

:ArchitectureDecision1 incose:informsDecision :TechnicalDecision1 .

:SystemDesign incose:basedOnDecision :TechnicalDecision1 .
```

---

## Usage Scenarios

### Scenario 1: Aerospace Product Development

**Context**: Developing a new satellite system with complex integration requirements

```turtle
:SatelliteSystem a incose:ProductSystem ;
    incose:hasContext :SpaceEnvironment ;
    incose:followsLifeCycleModel :VModel ;
    incose:usesDevelopmentApproach incose:SequentialDevelopment ;
    incose:hasStakeholder :SpaceAgency, :PrimeContractor ;
    incose:hasQualityAttribute :Reliability, :Safety .

:SpaceAgency a incose:Customer ;
    incose:hasRole "System Owner" ;
    incose:performsProcess :StakeholderNeedsDef .

:SystemRequirementsSpec a incose:Specification ;
    incose:derivedFrom :StakeholderNeedsDoc ;
    incose:status "Approved" .
```

### Scenario 2: Service System Design

**Context**: Designing an enterprise IT service

```turtle
:ITServiceSystem a incose:ServiceSystem ;
    incose:followsLifeCycleModel :ITILModel ;
    incose:usesDevelopmentApproach incose:AgileDevelopment ;
    incose:hasStakeholder :BusinessUsers, :ITOperations .

:ServiceDesignProcess a incose:SystemArchitectureDefinition ;
    incose:appliedDuringStage incose:DevelopmentStage ;
    incose:producesArtifact :ServiceArchitecture .
```

### Scenario 3: System of Systems Integration

**Context**: Integrating multiple independent defense systems

```turtle
:C4ISRSystem a incose:SystemOfSystems ;
    incose:composedOf :RadarSystem, :CommSystem, :CommandCenter ;
    incose:hasQualityAttribute :Interoperability, :Security .

:RadarSystem incose:partOf :C4ISRSystem ;
    incose:interactsWith :CommSystem, :CommandCenter .

:IntegrationArchitecture a incose:LogicalArchitecture ;
    incose:satisfiesRequirement :InteroperabilityReqs .
```

---

## Integration Patterns

### Integration with Domain Ontologies

The INCOSE core ontology is designed to be extended by domain-specific ontologies:

```turtle
# In a domain ontology (e.g., Aerospace)
@prefix aero: <https://ontologies.domain.com/aerospace/> .
@prefix incose: <https://ontologies.incose.org/sebok/core/> .

aero:AircraftSystem rdfs:subClassOf incose:ProductSystem .
aero:FlightControl rdfs:subClassOf incose:System .
aero:AircraftRequirement rdfs:subClassOf incose:Requirement .

# Specialized relationships
aero:hasAircraftSubsystem rdfs:subPropertyOf incose:composedOf .
aero:meetsAircraftStandard rdfs:subPropertyOf incose:satisfiesRequirement .
```

### Integration with Upper Ontologies

The ontology can be mapped to upper ontologies like BFO (Basic Formal Ontology):

```turtle
# Potential BFO mappings
incose:System rdfs:subClassOf bfo:MaterialEntity .
incose:Process rdfs:subClassOf bfo:Process .
incose:Artifact rdfs:subClassOf bfo:InformationContentEntity .
incose:LifeCycleStage rdfs:subClassOf bfo:TemporalRegion .
```

### Integration with Project Ontologies

```turtle
@prefix proj: <https://ontologies.domain.com/project/> .

proj:Project incose:performsProcess incose:ProjectPlanning .
proj:WorkPackage incose:producesArtifact incose:Artifact .
proj:Deliverable rdfs:subClassOf incose:Artifact .
proj:Milestone incose:appliedDuringStage incose:LifeCycleStage .
```

---

## SPARQL Query Examples

### Query 1: Find All Requirements for a System

```sparql
PREFIX incose: <https://ontologies.incose.org/sebok/core/>

SELECT ?req ?reqText ?stakeholder
WHERE {
    :MySystem incose:hasRequirement ?req .
    ?req incose:requirementText ?reqText .
    OPTIONAL { ?req incose:expressedBy ?stakeholder }
}
```

### Query 2: Trace Requirements to Architecture

```sparql
PREFIX incose: <https://ontologies.incose.org/sebok/core/>

SELECT ?req ?arch ?element
WHERE {
    ?req a incose:SystemRequirement ;
         incose:allocatedTo ?element .
    ?arch incose:implementsFunction ?element .
    :MySystem incose:hasArchitecture ?arch .
}
```

### Query 3: Find Processes Applied During Development Stage

```sparql
PREFIX incose: <https://ontologies.incose.org/sebok/core/>

SELECT ?process ?artifact
WHERE {
    ?process incose:appliedDuringStage incose:DevelopmentStage ;
             incose:producesArtifact ?artifact .
}
ORDER BY ?process
```

### Query 4: Identify System Dependencies

```sparql
PREFIX incose: <https://ontologies.incose.org/sebok/core/>

SELECT ?subsystem ?dependency ?relationship
WHERE {
    :MySystem incose:composedOf ?subsystem .
    {
        ?subsystem incose:dependsOn ?dependency .
        BIND("depends on" AS ?relationship)
    }
    UNION
    {
        ?subsystem incose:interactsWith ?dependency .
        BIND("interacts with" AS ?relationship)
    }
}
```

### Query 5: Find Unverified Requirements

```sparql
PREFIX incose: <https://ontologies.incose.org/sebok/core/>

SELECT ?req ?reqText
WHERE {
    :MySystem incose:hasRequirement ?req .
    ?req a incose:SystemRequirement ;
         incose:requirementText ?reqText .
    FILTER NOT EXISTS { ?req incose:verifiedBy ?verification }
}
```

### Query 6: Quality Attribute Coverage

```sparql
PREFIX incose: <https://ontologies.incose.org/sebok/core/>

SELECT ?system ?qualityAttr (COUNT(?req) AS ?reqCount)
WHERE {
    ?system incose:hasQualityAttribute ?qualityAttr .
    ?system incose:hasRequirement ?req .
    ?req incose:hasQualityAttribute ?qualityAttr .
}
GROUP BY ?system ?qualityAttr
ORDER BY ?system ?qualityAttr
```

### Query 7: Process Flow Analysis

```sparql
PREFIX incose: <https://ontologies.incose.org/sebok/core/>

SELECT ?process1 ?artifact ?process2
WHERE {
    ?process1 incose:producesArtifact ?artifact .
    ?process2 incose:consumesArtifact ?artifact .
    ?process1 incose:precedesProcess ?process2 .
}
ORDER BY ?process1
```

### Query 8: Stakeholder Responsibility Matrix

```sparql
PREFIX incose: <https://ontologies.incose.org/sebok/core/>

SELECT ?stakeholder ?role ?process ?artifact
WHERE {
    ?stakeholder incose:hasRole ?role ;
                 incose:performsProcess ?process .
    ?process incose:producesArtifact ?artifact .
}
ORDER BY ?stakeholder ?process
```

---

## Alignment with Standards

### ISO/IEC/IEEE 15288:2023 Mapping

| SEBoK/INCOSE Concept | ISO 15288 Concept |
|---------------------|-------------------|
| incose:LifeCycleProcess | Life Cycle Process |
| incose:TechnicalManagementProcess | Technical Management Processes |
| incose:SystemDefinitionProcess | Technical Processes (Stages 1-4) |
| incose:SystemRealizationProcess | Technical Processes (Implementation) |
| incose:SystemVerification | Verification Process |
| incose:SystemValidation | Validation Process |
| incose:ConfigurationManagement | Configuration Management Process |
| incose:RiskManagement | Risk Management Process |

### INCOSE Handbook v5.0 Alignment

The ontology directly implements concepts from:
- **Chapter 2**: System Life Cycle Processes
- **Chapter 3**: Technical Processes
- **Chapter 4**: Technical Management Processes
- **Chapter 5**: Agreement Processes (via Stakeholder)

### ISO/IEC/IEEE 42010 (Architecture)

- `incose:Architecture` aligns with ISO 42010 architecture concept
- `incose:hasArchitecture` represents architecture description
- Architecture types (Functional, Logical, Physical) represent viewpoints

---

## Extension Guidelines

### Creating Domain Extensions

1. **Subclass Core Concepts**
```turtle
:DomainSpecificSystem rdfs:subClassOf incose:EngineeredSystem .
```

2. **Specialize Relationships**
```turtle
:domainSpecificRelation rdfs:subPropertyOf incose:composedOf .
```

3. **Add Domain Properties**
```turtle
:domainMetric rdfs:subPropertyOf incose:description .
```

4. **Preserve Semantics**
- Maintain transitivity where inherited
- Preserve inverse relationships
- Ensure domain/range compatibility

### Best Practices

1. **Use Existing Relationships First**: Before creating new properties, check if existing ones can be specialized
2. **Maintain Traceability**: Always use `incose:tracesTo` and derivation relationships
3. **Document Rationale**: Use `incose:rationale` to explain design decisions
4. **Version Control**: Track versions of artifacts using `incose:version` and `incose:versionOf`
5. **Link to Sources**: Use `dct:source` to reference authoritative documents

---

## Governance and Evolution

### Change Management

Changes to this core ontology follow INCOSE governance:
1. Proposals reviewed by SEBoK editorial board
2. Alignment verified with ISO/IEC/IEEE standards
3. Community review period
4. Version numbering: Major.Minor.Patch

### Future Extensions

Planned extensions include:
- **Model-Based Systems Engineering (MBSE)**: Enhanced model semantics
- **Digital Engineering**: Integration with digital twin concepts
- **AI/ML Systems**: Specialized concepts for AI-intensive systems
- **Cyber-Physical Systems**: Enhanced physical-digital integration

---

## References

1. **SEBoK v2.13** (2025) - Systems Engineering Body of Knowledge
2. **ISO/IEC/IEEE 15288:2023** - Systems and software engineering — System life cycle processes
3. **ISO/IEC/IEEE 24748-1:2024** - Systems and software engineering — Life cycle management
4. **INCOSE Systems Engineering Handbook v5.0** (2023)
5. **ISO/IEC/IEEE 42010:2011** - Systems and software engineering — Architecture description

---

## Contact and Contribution

**Maintained by**: INCOSE SEBoK Community
**Version**: 1.0
**Last Updated**: February 2025
**License**: Creative Commons Attribution-ShareAlike 4.0 International

For questions, suggestions, or contributions, please contact the SEBoK editorial team or submit issues through the INCOSE community portal.

---

## Appendix: Quick Reference

### Common Prefixes

```turtle
@prefix incose: <https://ontologies.incose.org/sebok/core/> .
@prefix dct: <http://purl.org/dc/terms/> .
@prefix skos: <http://www.w3.org/2004/02/skos/core#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
```

### Essential Relationships Summary

| Relationship | Domain | Range | Description |
|-------------|--------|-------|-------------|
| hasContext | System | SystemContext | System's environment |
| composedOf | System | System | System decomposition |
| hasRequirement | System | Requirement | System requirements |
| satisfiesRequirement | System/Element | Requirement | Satisfaction relationship |
| hasArchitecture | System | Architecture | System architecture |
| hasLifeCycle | System | LifeCycle | System life cycle |
| appliedDuringStage | Process | LifeCycleStage | Process timing |
| producesArtifact | Process | Artifact | Process outputs |
| consumesArtifact | Process | Artifact | Process inputs |
| hasStakeholder | System | Stakeholder | Stakeholder involvement |
| verifiedBy | Element/Req | Verification | Verification linkage |
| validatedBy | System | Validation | Validation linkage |
| tracesTo | Artifact | Artifact | General traceability |

---

*End of Usage Guide*
