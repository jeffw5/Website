"""
evaluation.py
=============
Metrics that score a predicted task output against a gold one. These are the
objective the DSPy optimizer maximizes and the dashboard you watch instead of
editing prompts. Each metric has the DSPy signature `(example, prediction, trace)`
and returns a float in [0, 1].

The comparisons are deliberately forgiving on surface form (case/whitespace) and
strict on structure, which is what you want for extraction/linking quality.
"""

from __future__ import annotations

from typing import Iterable, Set


def _norm(s: str) -> str:
    return " ".join(str(s).lower().split())


def _f1(pred: Set[str], gold: Set[str]) -> float:
    if not pred and not gold:
        return 1.0
    if not pred or not gold:
        return 0.0
    tp = len(pred & gold)
    if tp == 0:
        return 0.0
    precision = tp / len(pred)
    recall = tp / len(gold)
    return 2 * precision * recall / (precision + recall)


def _get(obj, attr, default=None):
    """Work with either a Pydantic result or a plain dict."""
    if isinstance(obj, dict):
        return obj.get(attr, default)
    return getattr(obj, attr, default)


def _result(x):
    return _get(x, "result", x)


# --------------------------------------------------------------------------- #
def extraction_metric(example, prediction, trace=None) -> float:
    g, p = _result(example), _result(prediction)
    ents_g = {_norm(_get(e, "name", "")) for e in _get(g, "entities", []) or []}
    ents_p = {_norm(_get(e, "name", "")) for e in _get(p, "entities", []) or []}
    cons_g = {_norm(_get(c, "label", "")) for c in _get(g, "concepts", []) or []}
    cons_p = {_norm(_get(c, "label", "")) for c in _get(p, "concepts", []) or []}

    def triple(r):
        return (_norm(_get(r, "subject", "")), _norm(_get(r, "predicate", "")), _norm(_get(r, "object", "")))

    rels_g = {triple(r) for r in _get(g, "relationships", []) or []}
    rels_p = {triple(r) for r in _get(p, "relationships", []) or []}

    score = 0.4 * _f1(ents_p, ents_g) + 0.3 * _f1(cons_p, cons_g) + 0.3 * _f1(rels_p, rels_g)
    return score


def linking_metric(example, prediction, trace=None) -> float:
    g, p = _result(example), _result(prediction)
    gold = {_norm(_get(l, "framework_concept_id", "")) for l in _get(g, "links", []) or []}
    pred = {_norm(_get(l, "framework_concept_id", "")) for l in _get(p, "links", []) or []}
    return _f1(pred, gold)


def enrichment_metric(example, prediction, trace=None) -> float:
    g, p = _result(example), _result(prediction)
    audience = 1.0 if _norm(_get(g, "audience_level", "")) == _norm(_get(p, "audience_level", "")) else 0.0
    kw_g = {_norm(k) for k in _get(g, "keywords", []) or []}
    kw_p = {_norm(k) for k in _get(p, "keywords", []) or []}
    tp_g = {_norm(t) for t in _get(g, "topics", []) or []}
    tp_p = {_norm(t) for t in _get(p, "topics", []) or []}
    return 0.5 * audience + 0.3 * _f1(kw_p, kw_g) + 0.2 * _f1(tp_p, tp_g)


METRICS = {
    "extraction": extraction_metric,
    "linking": linking_metric,
    "enrichment": enrichment_metric,
}


def evaluate(module, devset: Iterable, metric) -> float:
    """Mean metric over a devset of DSPy Examples."""
    scores = []
    for ex in devset:
        pred = module(**{k: ex[k] for k in ex.inputs().keys()})
        scores.append(metric(ex, pred))
    return sum(scores) / len(scores) if scores else 0.0
