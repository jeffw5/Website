"""
optimize.py
===========
Turns accumulated feedback into better prompts. For each task it pulls the
trainset from the FeedbackStore, runs DSPy's MIPROv2 (Bayesian search over
instructions + few-shot demonstrations), validates against a held-out split, and
— only if the compiled program beats the current baseline — saves the artifact
to `compiled_dir`. Run it on a schedule or whenever the feedback set grows; you
never hand-edit a prompt.

    python -m avatar2.optimize --task extraction

Requires `dspy-ai`. Compilation makes API calls (cost scales with trainset size).
"""

from __future__ import annotations

import argparse
import logging
import os
from typing import List

from .config import Config
from .evaluation import METRICS, evaluate
from .feedback import FeedbackStore

logger = logging.getLogger("avatar2.optimize")

MIN_EXAMPLES = 20  # below this, MIPRO has too little signal — collect more first


def _split(examples: List, frac: float = 0.75):
    cut = max(1, int(len(examples) * frac))
    return examples[:cut], examples[cut:]


def compile_task(task: str, config: Config | None = None, auto: str = "light") -> float | None:
    """Compile one task; returns the validation score, or None if skipped."""
    import dspy
    from dspy.teleprompt import MIPROv2

    from .dspy_modules import _build

    config = config or Config()
    store = FeedbackStore(config.feedback_path)
    examples = store.export_trainset(task)
    if len(examples) < MIN_EXAMPLES:
        logger.warning("Only %d %s examples (< %d). Skipping.", len(examples), task, MIN_EXAMPLES)
        return None

    trainset, devset = _split(examples)
    metric = METRICS[task]
    module = _build(task, config)

    baseline = evaluate(module, devset, metric)
    logger.info("%s baseline dev score: %.3f", task, baseline)

    optimizer = MIPROv2(metric=metric, auto=auto)
    compiled = optimizer.compile(
        module, trainset=trainset, max_bootstrapped_demos=4, max_labeled_demos=4, requires_permission_to_run=False
    )

    new_score = evaluate(compiled, devset, metric)
    logger.info("%s compiled dev score: %.3f (baseline %.3f)", task, new_score, baseline)

    if new_score >= baseline:
        os.makedirs(config.compiled_dir, exist_ok=True)
        path = os.path.join(config.compiled_dir, f"{task}.json")
        compiled.save(path)
        logger.info("Promoted compiled %s -> %s", task, path)
    else:
        logger.info("Compiled %s did not beat baseline; keeping current artifact.", task)
    return new_score


def main():
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", choices=["extraction", "linking", "enrichment", "all"], default="all")
    ap.add_argument("--auto", choices=["light", "medium", "heavy"], default="light")
    args = ap.parse_args()
    cfg = Config()
    tasks = ["extraction", "linking", "enrichment"] if args.task == "all" else [args.task]
    for t in tasks:
        compile_task(t, cfg, auto=args.auto)


if __name__ == "__main__":
    main()
