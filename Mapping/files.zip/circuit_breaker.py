"""
circuit_breaker.py
==================
AI CIRCUIT BREAKER — the governance membrane around each reasoning holon.

Design lineage (your frameworks):
  * STPA/STAMP — each agent output is a *control action* into the knowledge base.
    We classify failures using the four canonical Unsafe Control Action (UCA)
    types and refuse to let an unsafe action persist.
  * RDSG Simplex Action Gateway — when the complex (LLM) controller emits an
    unsafe action, a verified safe controller takes over. Here "safe" is
    conservative: strip the unverified assertion and quarantine it for review
    rather than writing it to the governed KB. Fail safe, not fail open.
  * HOVA governance quad-tuple — every decision is recorded as
    <Hazard, Observable, Verdict, Action>. (Field names below map to that shape;
    confirm against your canonical HOVA definition.)
  * MTBH — Mean Time Between Hazards is the health metric across the holarchy.
  * Holonic immune system — breakers compose: a membrane per agent-holon, a
    monitor for the pipeline-holon. Each is a whole and a part.

The breaker operates at the granularity of individual control actions (a claim,
a relationship, a framework link) so a single bad triple is quarantined without
discarding the rest of a chunk. Quarantined actions flow to the FeedbackStore as
review items — so governance trips become tomorrow's training signal.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Callable, List, Optional, Tuple

from .config import Config
from .models import Chunk

logger = logging.getLogger("avatar2.breaker")


# --------------------------------------------------------------------------- #
# Vocabularies
# --------------------------------------------------------------------------- #
class UCAType(str, Enum):
    """The four STPA Unsafe Control Action types, mapped to ingestion."""

    PROVIDED_UNSAFE = "provided_unsafe"          # asserting a low-confidence/ungrounded action
    NOT_PROVIDED = "not_provided"                # a required element (evidence, provenance) is missing
    WRONG_ORDER = "wrong_order"                  # out-of-order / stale (e.g. embed before govern)
    APPLIED_TOO_LONG = "applied_too_long"        # low-confidence item persisted without review


class Verdict(str, Enum):
    PASS = "pass"
    WARN = "warn"
    TRIP = "trip"


class Action(str, Enum):
    ALLOW = "allow"
    QUARANTINE = "quarantine"
    FALLBACK = "fallback"      # Simplex safe controller engaged


@dataclass
class GovernanceRecord:
    """HOVA quad-tuple: <Hazard, Observable, Verdict, Action> + provenance."""

    hazard: UCAType                 # H
    observable: str                 # O — what was observed (the offending content)
    verdict: Verdict                # V
    action: Action                  # A
    constraint: str = ""
    chunk_id: str = ""
    target_kind: str = ""           # claim | relationship | link | chunk
    target_id: str = ""
    confidence: Optional[float] = None
    at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def as_dict(self) -> dict:
        return {
            "hazard": self.hazard.value,
            "observable": self.observable[:300],
            "verdict": self.verdict.value,
            "action": self.action.value,
            "constraint": self.constraint,
            "chunk_id": self.chunk_id,
            "target_kind": self.target_kind,
            "target_id": self.target_id,
            "confidence": self.confidence,
            "at": self.at,
        }


# --------------------------------------------------------------------------- #
# Constraints — each inspects a chunk and returns (records, ids_to_strip)
# --------------------------------------------------------------------------- #
Constraint = Callable[[Chunk, Config], Tuple[List[GovernanceRecord], dict]]


def _strip_set() -> dict:
    return {"claims": set(), "relationships": set(), "links": set()}


def evidence_constraint(chunk: Chunk, cfg: Config):
    """UCA NOT_PROVIDED: claims/relationships asserted without supporting evidence."""
    recs, strip = [], _strip_set()
    if cfg.require_evidence_for_claims:
        for c in chunk.claims:
            if not (c.source_span and c.source_span.strip()):
                recs.append(GovernanceRecord(
                    UCAType.NOT_PROVIDED, c.text, Verdict.TRIP, Action.QUARANTINE,
                    "evidence_required", chunk.id, "claim", c.id, c.confidence))
                strip["claims"].add(c.id)
    if cfg.require_evidence_for_relationships:
        for r in chunk.relationships:
            if not (r.evidence and r.evidence.strip()):
                recs.append(GovernanceRecord(
                    UCAType.NOT_PROVIDED, f"{r.subject} {r.predicate} {r.object}",
                    Verdict.TRIP, Action.QUARANTINE, "evidence_required",
                    chunk.id, "relationship", r.id, r.confidence))
                strip["relationships"].add(r.id)
    return recs, strip


def confidence_constraint(chunk: Chunk, cfg: Config):
    """UCA PROVIDED_UNSAFE / APPLIED_TOO_LONG: asserting below-threshold confidence."""
    recs, strip = [], _strip_set()
    for c in chunk.claims:
        if c.confidence < cfg.min_claim_confidence:
            recs.append(GovernanceRecord(
                UCAType.PROVIDED_UNSAFE, c.text, Verdict.TRIP, Action.QUARANTINE,
                "min_claim_confidence", chunk.id, "claim", c.id, c.confidence))
            strip["claims"].add(c.id)
    for l in chunk.framework_links:
        if l.confidence < cfg.min_link_confidence:
            recs.append(GovernanceRecord(
                UCAType.PROVIDED_UNSAFE, l.framework_label, Verdict.TRIP, Action.QUARANTINE,
                "min_link_confidence", chunk.id, "link", l.framework_concept_id, l.confidence))
            strip["links"].add(l.framework_concept_id)
    return recs, strip


def iri_resolution_constraint(chunk: Chunk, cfg: Config):
    """Consistency with the value-kb backbone: a link must resolve to an IRI."""
    recs, strip = [], _strip_set()
    if not cfg.require_resolved_iri:
        return recs, strip
    for l in chunk.framework_links:
        if not (l.framework_iri and l.framework_iri.strip()):
            recs.append(GovernanceRecord(
                UCAType.PROVIDED_UNSAFE, l.framework_label, Verdict.WARN, Action.QUARANTINE,
                "iri_must_resolve", chunk.id, "link", l.framework_concept_id, l.confidence))
            strip["links"].add(l.framework_concept_id)
    return recs, strip


def provenance_constraint(chunk: Chunk, cfg: Config):
    """UCA NOT_PROVIDED at chunk scope: no document lineage -> whole chunk unsafe."""
    recs, strip = [], _strip_set()
    if not chunk.document_id:
        recs.append(GovernanceRecord(
            UCAType.NOT_PROVIDED, "missing document lineage", Verdict.TRIP, Action.QUARANTINE,
            "provenance_required", chunk.id, "chunk", chunk.id))
        strip["_chunk"] = True
    return recs, strip


DEFAULT_CONSTRAINTS: List[Constraint] = [
    provenance_constraint,
    evidence_constraint,
    confidence_constraint,
    iri_resolution_constraint,
]


# --------------------------------------------------------------------------- #
# Simplex gateway + MTBH monitor + the breaker holon
# --------------------------------------------------------------------------- #
class MTBHMonitor:
    """Mean Time Between Hazards over a rolling window of control actions.

    Action-count based: MTBH = actions_processed / hazards. Higher is healthier.
    (Swap in wall-clock by feeding timestamps if your metrology requires it.)
    """

    def __init__(self, window: int = 500):
        self.window = window
        self.actions = 0
        self.hazards = 0

    def record_action(self, n: int = 1):
        self.actions += n

    def record_hazard(self, n: int = 1):
        self.hazards += n

    def mtbh(self) -> float:
        return self.actions / self.hazards if self.hazards else float(self.actions or 0)

    def hazard_rate(self) -> float:
        return self.hazards / self.actions if self.actions else 0.0


@dataclass
class GuardResult:
    chunk: Chunk
    verdict: Verdict
    records: List[GovernanceRecord]
    quarantined: List[GovernanceRecord]


class CircuitBreaker:
    """One holon's governance membrane: constraints + Simplex fallback + monitor."""

    def __init__(self, config: Config, constraints: Optional[List[Constraint]] = None,
                 monitor: Optional[MTBHMonitor] = None):
        self.config = config
        self.constraints = constraints or DEFAULT_CONSTRAINTS
        self.monitor = monitor or MTBHMonitor(config.mtbh_window)

    def guard(self, chunk: Chunk) -> GuardResult:
        actions = len(chunk.claims) + len(chunk.relationships) + len(chunk.framework_links) or 1
        self.monitor.record_action(actions)

        all_recs: List[GovernanceRecord] = []
        strip = _strip_set()
        chunk_level_trip = False
        for constraint in self.constraints:
            recs, s = constraint(chunk, self.config)
            all_recs.extend(recs)
            for k in ("claims", "relationships", "links"):
                strip[k] |= s.get(k, set())
            if s.get("_chunk"):
                chunk_level_trip = True

        verdict = Verdict.PASS
        if any(r.verdict == Verdict.TRIP for r in all_recs) or chunk_level_trip:
            verdict = Verdict.TRIP
        elif any(r.verdict == Verdict.WARN for r in all_recs):
            verdict = Verdict.WARN

        # Simplex safe controller: remove offending actions; quarantine the rest
        if chunk_level_trip:
            chunk.quarantined = True
        else:
            chunk.claims = [c for c in chunk.claims if c.id not in strip["claims"]]
            chunk.relationships = [r for r in chunk.relationships if r.id not in strip["relationships"]]
            chunk.framework_links = [
                l for l in chunk.framework_links if l.framework_concept_id not in strip["links"]
            ]

        hazards = sum(1 for r in all_recs if r.verdict == Verdict.TRIP)
        self.monitor.record_hazard(hazards)
        chunk.governance_records.extend(r.as_dict() for r in all_recs)

        quarantined = [r for r in all_recs if r.action in (Action.QUARANTINE, Action.FALLBACK)]
        return GuardResult(chunk, verdict, all_recs, quarantined)


# --------------------------------------------------------------------------- #
# Holonic governor — the pipeline-holon's immune system
# --------------------------------------------------------------------------- #
@dataclass
class GovernanceReport:
    chunks_reviewed: int = 0
    chunks_quarantined: int = 0
    actions_stripped: int = 0
    trips: int = 0
    warnings: int = 0
    mtbh: float = 0.0
    hazard_rate: float = 0.0
    records: List[dict] = field(default_factory=list)


class HolonicGovernor:
    """Runs a circuit breaker across the corpus and (optionally) routes
    quarantined actions to the FeedbackStore so they re-enter as training signal."""

    def __init__(self, config: Config, breaker: Optional[CircuitBreaker] = None):
        self.config = config
        self.breaker = breaker or CircuitBreaker(config)

    def review(self, extractions, feedback_store=None) -> GovernanceReport:
        report = GovernanceReport()
        for ex in extractions:
            for chunk in ex.chunks:
                result = self.breaker.guard(chunk)
                report.chunks_reviewed += 1
                report.trips += sum(1 for r in result.records if r.verdict == Verdict.TRIP)
                report.warnings += sum(1 for r in result.records if r.verdict == Verdict.WARN)
                report.actions_stripped += len(result.quarantined)
                if chunk.quarantined:
                    report.chunks_quarantined += 1
                report.records.extend(r.as_dict() for r in result.records)
                if feedback_store is not None and result.quarantined:
                    self._to_feedback(chunk, result, feedback_store)
        report.mtbh = self.breaker.monitor.mtbh()
        report.hazard_rate = self.breaker.monitor.hazard_rate()
        logger.info(
            "Governance: %d chunks, %d trips, %d quarantined, MTBH=%.1f",
            report.chunks_reviewed, report.trips, report.chunks_quarantined, report.mtbh,
        )
        return report

    @staticmethod
    def _to_feedback(chunk: Chunk, result: GuardResult, store) -> None:
        from .feedback import ReviewRecord

        kind_to_task = {"claim": "extraction", "relationship": "extraction", "link": "linking",
                        "chunk": "extraction"}
        for r in result.quarantined:
            store.record(ReviewRecord(
                task=kind_to_task.get(r.target_kind, "extraction"),
                verdict="reject", source="breaker",
                chunk_id=chunk.id, document_title=chunk.document_title, chunk_text=chunk.text,
                inputs={"document_title": chunk.document_title, "chunk": chunk.text},
                note=f"{r.hazard.value}:{r.constraint} -> {r.observable[:120]}",
            ))
