"""
feedback.py
===========
The feedback store is what turns the pipeline from static into adaptive. Every
human accept / reject / edit on an extraction, link, or enrichment — and every
item the AI Circuit Breaker quarantines — is appended here as a review record.

That single store does triple duty:
  * few-shot exemplars at inference time,
  * the trainset/devset the DSPy optimizer compiles against (optimize.py), and
  * (only if volume ever justifies it) fine-tuning data for a narrow classifier.

Records are line-delimited JSON so the store is append-only, diffable, and cheap
to stream. `export_trainset(task)` yields DSPy Examples on demand.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from typing import Dict, Iterator, List, Literal, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger("avatar2.feedback")

Task = Literal["extraction", "linking", "enrichment"]
Verdict = Literal["accept", "reject", "edit"]
Source = Literal["human", "breaker"]


class ReviewRecord(BaseModel):
    task: Task
    verdict: Verdict
    source: Source = "human"
    chunk_id: str
    document_title: str
    chunk_text: str
    # inputs needed to replay the task as a training example
    inputs: Dict[str, str] = Field(default_factory=dict)
    # the corrected/approved output as a plain dict (matches the task's result model)
    gold: Dict = Field(default_factory=dict)
    note: str = ""
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class FeedbackStore:
    def __init__(self, path: str):
        self.path = path
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)

    def record(self, review: ReviewRecord) -> None:
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(review.model_dump_json() + "\n")

    def all(self) -> Iterator[ReviewRecord]:
        if not os.path.exists(self.path):
            return
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    yield ReviewRecord.model_validate_json(line)

    def gold_for(self, task: Task) -> List[ReviewRecord]:
        """Records usable as supervision: accepted or edited (not rejected-only)."""
        return [r for r in self.all() if r.task == task and r.verdict in ("accept", "edit")]

    def export_trainset(self, task: Task) -> List:
        """Build a DSPy trainset for a task from approved/edited records."""
        import dspy

        examples = []
        for r in self.gold_for(task):
            fields = dict(r.inputs)
            fields["result"] = r.gold
            ex = dspy.Example(**fields).with_inputs(*r.inputs.keys())
            examples.append(ex)
        logger.info("Exported %d %s training examples", len(examples), task)
        return examples
