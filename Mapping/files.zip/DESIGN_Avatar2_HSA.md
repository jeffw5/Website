# Avatar 2.0 — Staged Architecture & Implementation Design

*An adaptive, ontology-grounded, governed semantic ingestion holarchy*

Status: draft for staged build-out · Owner: Jeffrey Wallk / The Value Enablement Group · Companion to the `avatar2` reference implementation

---

## 1. Purpose and how to read this

This document specifies how to build Avatar 2.0 end-to-end in stages, so that each stage is independently demonstrable and the whole composes into a customer-ready reference architecture for governed, self-improving knowledge ingestion. It folds together three threads developed so far: the four-agent ingestion pipeline, the decision to ground it top-down in the `value-kb` ontology, and the decision to make it adaptive (prompts compiled from feedback rather than hand-maintained) and governed (an AI Circuit Breaker between the agents and the knowledge base).

The framing is deliberately your own: the system is described as a **Holonic Semantic Architecture (HSA)** — a holarchy of ingestion holons, each a whole and a part, each wrapped in a governance membrane, all coordinated by a shared semantic backbone. Sections 2–6 are the architecture; Section 7 is the staged build plan; Section 8 is the demo story; Sections 9–11 are decisions, the module map, and a glossary.

## 2. Architectural thesis

Three commitments, in priority order, define the system and resolve most design tradeoffs:

**Grounded.** Meaning comes top-down from the curated ontology in GraphDB `value-kb`, not bottom-up from whatever a model happens to extract. The ontology is the control surface: changing behavior is a curation act on the knowledge graph, not a code change.

**Adaptive.** The system improves from human corrections without anyone editing prompt strings or model weights. Prompts are declarative signatures compiled against a feedback-derived evaluation metric; the ontology and the feedback store carry the variability that would otherwise live in Python.

**Governed.** No unverified assertion reaches the knowledge base. Every agent output passes a governance membrane modeled on STPA/STAMP and the RDSG Simplex Action Gateway, with Mean Time Between Hazards (MTBH) as the health metric. This is the AI Circuit Breaker applied to the system's own plumbing.

The deliberate non-goal: **autonomous orchestration.** The control flow stays a legible, deterministic DAG with human checkpoints. Intelligence lives *inside* the holons; the holarchy's wiring stays auditable. On a path that writes into a governed KB, determinism and provenance are features, not limitations.

## 3. The Holonic Semantic Architecture frame

A *holon* is simultaneously a whole and a part. Avatar 2.0 is a *holarchy* of ingestion holons:

- **Pipeline holon** — the whole ingestion run. Owns the shared backbone, the cross-holon MTBH monitor, and the human-approval checkpoint.
- **Stage holons** — Extraction, Relationship Mining, Enrichment, Embedding. Each is a complete unit of work and a part of the pipeline.
- **Sub-holons within each stage** — three faces every reasoning stage presents:
  1. a **reasoning core** (a DSPy module whose prompt is compiled, not authored),
  2. a **governance membrane** (a circuit breaker enforcing UCA constraints), and
  3. a **provenance interface** (reads the ontology, writes provenance-stamped results).

Two cross-cutting structures bind the holarchy:

- **The semantic backbone** — the `value-kb` ontology, loaded once and shared by every reasoning core. It is the top-down grounding that makes the holons coherent rather than independently inventive.
- **The immune system** — the composed circuit breakers. Local membranes catch local hazards; the pipeline-level monitor aggregates them into MTBH and routes quarantined material to the feedback store.

```
                ┌─────────────────────────  value-kb ontology (backbone)  ─────────────────────────┐
                │            OWL classes · SKOS concepts · taxonomy · object properties             │
                └───────────────┬───────────────┬───────────────┬───────────────┬──────────────────┘
                                ▼               ▼               ▼               ▼
 Documents ─▶  [ Extraction ] ─▶ [ Mining ] ─▶ [ Enrichment ] ─▶ │ Circuit │ ─▶ [ Embedding ] ─▶ Pinecone
                  holon            holon          holon          │ Breaker │       holon
                    │                │              │            │ membrane│
                    └──── corrections + quarantines ─┴──────────▶ Feedback store ──▶ DSPy compile ──▶ better prompts
                                                                       │
                                                                  MTBH monitor (immune system health)
```

## 4. Reference architecture

**Reasoning cores (adaptive).** Extraction, framework linking, and enrichment are DSPy modules (`dspy_modules.py`, `dspy_agents.py`). Each is a typed signature — inputs to a typed Pydantic output — whose instruction is a seed and whose final prompt (instructions plus few-shot demonstrations) is compiled from the feedback set. At runtime each module loads its compiled artifact from `compiled/` if present and otherwise runs the seed, so the pipeline works before any optimization has happened. The Embedding stage is deterministic and needs no reasoning core.

**Governance membranes (the AI Circuit Breaker).** `circuit_breaker.py` wraps the post-enrichment output of each chunk. It inspects individual control actions — a claim, a relationship, a framework link — against UCA-derived constraints, strips the offending ones via a Simplex safe controller, records each decision as a HOVA quad-tuple, and updates MTBH. The rest of the chunk proceeds; only unsalvageable chunks are quarantined whole.

**Provenance interfaces.** Mining writes `framework ← claim ← chunk ← document` provenance chains with real `value-kb` IRIs. Stage 1 extends this to write those chains back into a named graph in GraphDB, closing the loop between what the avatar knows and where it came from.

**The adaptation loop.** Human corrections and breaker quarantines land in the feedback store (`feedback.py`) as review records. `optimize.py` exports them as a DSPy trainset, runs MIPROv2, validates against a held-out split, and promotes the compiled artifact only if it beats the current baseline on the metric (`evaluation.py`). Nothing is hand-tuned and nothing is promoted blind.

**The metric.** MTBH (`MTBHMonitor`) is the cross-holon health signal: control actions processed per hazard tripped. It is the number on the governance dashboard and the leading indicator of whether the reasoning cores are drifting.

## 5. The adaptation model — what "train" means here

"Train" is overloaded; for this system it resolves to three concrete mechanisms, in descending order of leverage:

1. **Curate the ontology.** Because extraction, mining, and enrichment are grounded in `value-kb`, adding a concept, an `altLabel`, a `broader` edge, or an object property changes behavior across every stage with zero code change. This is the highest-leverage and lowest-risk form of adaptation, and it is already wired.
2. **Compile prompts from feedback.** The reasoning cores never carry hand-edited prompt text. You maintain a folder of reviewed examples and a scoring metric; MIPROv2 searches instructions and demonstrations to maximize the metric. The optimizer never touches weights — its only output is a better prompt — and it is re-run when the feedback set grows, not continuously.
3. **Fine-tune, only at the margin.** Weight fine-tuning is intentionally a last resort. It is narrow today (Claude Haiku, via Bedrock), it adapts *behavior*, not *knowledge*, and your knowledge lives in the backbone. The only candidate is a high-volume, narrow sub-task — audience classification is the likeliest — where a fine-tuned Haiku classifier trained on accumulated feedback would cut cost and latency. Treat it as an optimization to earn, not a default.

The throughline: variability that would otherwise force you to edit Python is pushed into data — the ontology and the feedback store — and into compiled artifacts. Your standing work shifts from editing files to curating the graph, approving corrections, and watching the evaluation and MTBH dashboards.

## 6. The governance model — AI Circuit Breaker

The circuit breaker treats each agent output as a *control action* into the knowledge base and refuses to let an unsafe one persist. Its design maps directly onto your frameworks.

**STPA Unsafe Control Action mapping.** The four canonical UCA types are mapped to ingestion hazards and to enforcing constraints:

| STPA UCA type | Ingestion hazard | Enforcing constraint |
|---|---|---|
| Control action provided but unsafe | Asserting a low-confidence or ungrounded triple/link | `confidence_constraint` (below `min_*_confidence`) |
| Required control action not provided | A claim/relationship lacks supporting evidence; a chunk lacks lineage | `evidence_constraint`, `provenance_constraint` |
| Provided in wrong order / too early | Writing to the KB before governance, or against a stale ontology | pipeline ordering (govern before embed) |
| Applied too long / stopped too soon | A low-confidence item persisted without review | `confidence_constraint` + quarantine-to-review |

**Simplex Action Gateway.** When the complex (LLM) controller emits an unsafe action, the verified safe controller takes over. Here "safe" is conservative: remove the offending assertion and quarantine it for human review rather than writing it. The breaker fails safe, not open — the cost of a trip is a missed assertion (recoverable via review), never a corrupted KB.

**HOVA governance quad-tuple.** Every decision is recorded as ⟨Hazard, Observable, Verdict, Action⟩ with provenance (chunk, target, confidence, timestamp). This is the auditable trail a regulated customer will ask for. *Note:* the field shape here is an interpretation of HOVA; confirm it against your canonical definition and adjust `GovernanceRecord` field names to match before customer use.

**MTBH.** Mean Time Between Hazards = control actions processed ÷ hazards tripped, over a rolling window. It is action-count based by default; feed timestamps to switch to wall-clock if your metrology requires it. Rising MTBH means the reasoning cores are getting safer (usually after a good compile); a sudden drop is the early-warning signal to inspect a stage.

**Holonic immune system.** Breakers compose. Each stage holon can carry its own membrane with stage-specific constraints; the pipeline holon aggregates them into one MTBH and one quarantine queue. The same pattern scales out when new holons (new document types, new agents) are added.

**The governance/adaptation unification.** A trip is not just a block — it is a labeled training signal. Quarantined actions flow into the feedback store as breaker-sourced review records; a human later corrects or confirms them; that correction becomes a demonstration the next compile learns from. Governance and adaptation are the same loop viewed from two ends.

## 7. Staged implementation roadmap

Each stage is independently demonstrable, ships a concrete artifact, and has an exit criterion before the next begins.

| Stage | Objective | Key build | Exit criterion | Demo hook |
|---|---|---|---|---|
| 0 — Grounded baseline | Deterministic 4-agent pipeline grounded in value-kb | `extraction/mining/enrichment/embedding`, `ontology.from_graphdb` | A document ingests end-to-end; provenance chains reference real IRIs | "Watch it extract against *your* ontology" |
| 1 — Provenance & capture | Write provenance to a named graph; capture human review | Provenance write-back; `FeedbackStore`; minimal review UX | Reviews accumulate as records; chains queryable in GraphDB | "Every fact traces to its source" |
| 2 — Adaptive prompts | Reasoning cores become compiled DSPy modules | `dspy_modules`, `dspy_agents`, `evaluation`, `optimize` | A compile beats the seed on the eval metric; artifact promoted | "It got better and no one edited a prompt" |
| 3 — Governance membrane | AI Circuit Breaker between enrichment and KB | `circuit_breaker`, MTBH monitor, quarantine→feedback | Injected bad output trips; KB stays clean; MTBH reported | "The bad fact never made it in" |
| 4 — Closed adaptive loop | Scheduled, eval-gated recompilation; optional Haiku fine-tune | optimize on a schedule; promotion gate; (optional) Bedrock tune | Quarantines fall / MTBH rises across cycles | "Corrections today, fewer trips tomorrow" |
| 5 — Holonic scale-out | New holons via a capability/tool registry; multi-domain ontologies | MCP/tool registry; per-holon membranes; domain ontologies | A new document type added with no pipeline rewrite | "Same governance, new domain, one afternoon" |

Per-stage notes:

- **Stage 1** is unglamorous but load-bearing — without captured feedback, Stages 2 and 4 have no signal. Ship the simplest possible review surface first; richness can follow.
- **Stage 2** can run on the prompt-based agents in production while the DSPy cores are validated offline; flip `agent_engine` to `dspy` only after a compile clears the gate.
- **Stage 3** is where the customer story sharpens — it is the visible "AI governance" capability your market (SE4AI, regulated industries) is buying. Build a small set of high-signal constraints first; breadth later.
- **Stage 4** is also where you decide the fine-tune ROI question with real numbers rather than in the abstract.
- **Stage 5** is the generalization that turns a single avatar into a platform.

## 8. Customer demo narrative

A six-beat story that lands the three commitments without slides:

1. **Grounding.** Drop in one of the customer's own documents. Show extraction snapping to *their* ontology labels and predicates — not generic NER. (Stage 0)
2. **Provenance.** Click any extracted fact; trace the chain back to the exact source span and the governing concept in their graph. (Stage 1)
3. **A hazard.** Feed a document with a planted unsupported claim. Watch the circuit breaker trip, quarantine the claim, and keep the rest. The KB stays clean. (Stage 3)
4. **The audit trail.** Show the HOVA record and the live MTBH figure — the governance evidence a regulator would want. (Stage 3)
5. **Correction.** A reviewer fixes the quarantined item; it lands in the feedback store. (Stage 1+3)
6. **Improvement.** Recompile; show the metric rise and the same hazard no longer tripping. The system learned without a code change. (Stage 2+4)

The arc is the pitch: *grounded in your knowledge, governed so you can trust it, and improving from your experts — without a maintenance burden.*

## 9. Decisions, risks, and open questions

- **HOVA canonical mapping.** The quad-tuple field names are an interpretation. Confirm the authoritative HOVA semantics and reconcile `GovernanceRecord` before any customer-facing use.
- **Ontology scale.** Injecting the whole `value-kb` scaffold into every extraction prompt is fine for a small ontology and wrong for a large one (cost, dilution). The fix is a retrieval shortlist: embed concept labels, fetch the top-k relevant to each chunk, and build a per-chunk scaffold. Decide the threshold at which to switch.
- **Named-graph governance.** Provenance write-back must respect the same `context` scoping used elsewhere; settle the target graph IRI(s) before Stage 1.
- **Fine-tune ROI.** Defer until Stage 4 and decide with measured volume/cost for the narrow sub-task, not in the abstract.
- **Review UX.** The human checkpoint is the one irreducible piece of standing work. Its ergonomics determine how much feedback you actually capture; treat it as a first-class surface, not an afterthought.
- **Constraint calibration.** Confidence thresholds and which UCAs are TRIP vs WARN are policy. Start conservative (more quarantine, higher recall on hazards), then relax as MTBH and review load justify.

## 10. Module map

| File | Responsibility | First stage |
|---|---|---|
| `models.py` | Typed contracts (entities, claims, chunks, provenance, governance fields) | 0 |
| `chunking.py` | Sentence-aware chunker with overlap | 0 |
| `graphdb.py` | RDF4J SPARQL client for value-kb | 0 |
| `ontology.py` | Ontology backbone; `from_graphdb`; scaffold/catalog renderings | 0 |
| `extraction_agent.py` · `relationship_mining_agent.py` · `enrichment_agent.py` · `embedding_agent.py` | Prompt-based reasoning cores + deterministic embedding | 0 |
| `pipeline.py` | Orchestration, engine selection, governance pass, stats | 0 |
| `feedback.py` | Review store; DSPy trainset export | 1 |
| `dspy_modules.py` · `dspy_agents.py` | Compiled reasoning cores (drop-in for the prompt agents) | 2 |
| `evaluation.py` · `optimize.py` | Metrics; MIPROv2 compile + eval-gated promotion | 2 |
| `circuit_breaker.py` | UCA constraints, Simplex gateway, HOVA records, MTBH, holonic governor | 3 |

## 11. Glossary

- **Holon / holarchy** — a unit that is both a whole and a part; a hierarchy of such units.
- **Backbone** — the shared `value-kb` ontology grounding every reasoning core.
- **Membrane** — a holon's circuit breaker; its governance boundary.
- **UCA** — Unsafe Control Action (STPA); the four failure modes a control action can exhibit.
- **Simplex gateway** — verified safe controller that supersedes the complex controller on an unsafe action.
- **HOVA** — the governance quad-tuple recorded per decision ⟨Hazard, Observable, Verdict, Action⟩.
- **MTBH** — Mean Time Between Hazards; the holarchy's health metric.
- **Compiled artifact** — the optimized prompt/demonstration bundle DSPy emits; what you version instead of prompt strings.
