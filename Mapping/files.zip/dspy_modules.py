"""
dspy_modules.py
===============
The three reasoning agents re-expressed as DSPy modules. Instead of a
hand-maintained system-prompt string, each task is a declarative *signature*
(typed inputs -> typed output). The docstring is the SEED instruction; the real
prompt — instructions + few-shot demonstrations — is COMPILED from your feedback
set by an optimizer (see optimize.py) and saved to `compiled_dir`. The optimizer
never touches model weights; its only output is a better prompt.

At runtime, `build_*_module()` loads the compiled artifact if present and falls
back to the seed otherwise, so the pipeline runs before you have ever optimized.

Requires `dspy-ai`. Imported lazily so the rest of the package loads without it.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

from .config import Config
from .models import ConceptLinkResult, EnrichmentResult, ExtractionResult

logger = logging.getLogger("avatar2.dspy")

_CONFIGURED = False


def configure_dspy(config: Config) -> None:
    """Point DSPy at the Anthropic model. Idempotent."""
    global _CONFIGURED
    if _CONFIGURED:
        return
    import dspy

    config.require("anthropic_api_key")
    lm = dspy.LM(
        model=f"anthropic/{config.extraction_model}",
        api_key=config.anthropic_api_key,
        max_tokens=config.max_tokens,
    )
    dspy.configure(lm=lm)
    _CONFIGURED = True


# --------------------------------------------------------------------------- #
# Signatures — the declarative contracts. Docstrings are SEED instructions.
# --------------------------------------------------------------------------- #
def _signatures():
    import dspy

    class ExtractFromChunk(dspy.Signature):
        """Extract entities, concepts, subject-predicate-object relationships, and
        typed claims from a chunk of a technical knowledge base. Ground the
        extraction in the ontology scaffold: when an item matches a listed class
        or concept, use that canonical label; when a relationship matches a listed
        predicate, prefer it. The scaffold grounds but does not limit you — still
        capture novel items. Extract only what the text supports; never fabricate."""

        document_title: str = dspy.InputField()
        ontology_scaffold: str = dspy.InputField(desc="Governing schema; may be empty.")
        chunk: str = dspy.InputField()
        result: ExtractionResult = dspy.OutputField()

    class LinkToFrameworks(dspy.Signature):
        """Identify which framework concepts (from the catalog) a chunk genuinely
        engages with. For each, choose the most specific relation
        (mentions|defines|applies|extends|critiques), use the exact
        framework_concept_id, and give a short verbatim evidence span. Link only
        concepts actually present; return an empty list if none match."""

        ontology_catalog: str = dspy.InputField()
        chunk: str = dspy.InputField()
        result: ConceptLinkResult = dspy.OutputField()

    class EnrichChunk(dspy.Signature):
        """Add a retrieval-oriented metadata layer to a chunk: a self-contained
        summary, precise keywords, higher-level topics, controlled semantic tags,
        and an audience_level (novice|practitioner|expert) classifying the depth
        the chunk best serves, with a one-sentence rationale. Be specific and
        grounded; do not pad lists with generic terms."""

        document_title: str = dspy.InputField()
        chunk: str = dspy.InputField()
        known_concepts: str = dspy.InputField(desc="Concepts already extracted.")
        known_frameworks: str = dspy.InputField(desc="Frameworks already linked.")
        result: EnrichmentResult = dspy.OutputField()

    return ExtractFromChunk, LinkToFrameworks, EnrichChunk


# --------------------------------------------------------------------------- #
# Modules
# --------------------------------------------------------------------------- #
def _module_classes():
    import dspy

    ExtractFromChunk, LinkToFrameworks, EnrichChunk = _signatures()

    class ExtractionModule(dspy.Module):
        def __init__(self):
            super().__init__()
            self.extract = dspy.Predict(ExtractFromChunk)

        def forward(self, document_title, ontology_scaffold, chunk):
            return self.extract(
                document_title=document_title, ontology_scaffold=ontology_scaffold, chunk=chunk
            )

    class LinkingModule(dspy.Module):
        def __init__(self):
            super().__init__()
            self.link = dspy.Predict(LinkToFrameworks)

        def forward(self, ontology_catalog, chunk):
            return self.link(ontology_catalog=ontology_catalog, chunk=chunk)

    class EnrichmentModule(dspy.Module):
        def __init__(self):
            super().__init__()
            self.enrich = dspy.Predict(EnrichChunk)

        def forward(self, document_title, chunk, known_concepts, known_frameworks):
            return self.enrich(
                document_title=document_title,
                chunk=chunk,
                known_concepts=known_concepts,
                known_frameworks=known_frameworks,
            )

    return ExtractionModule, LinkingModule, EnrichmentModule


# --------------------------------------------------------------------------- #
# Builders — load compiled artifact if present, else seed
# --------------------------------------------------------------------------- #
def _build(kind: str, config: Config):
    configure_dspy(config)
    ExtractionModule, LinkingModule, EnrichmentModule = _module_classes()
    module = {"extraction": ExtractionModule, "linking": LinkingModule, "enrichment": EnrichmentModule}[kind]()
    path = os.path.join(config.compiled_dir, f"{kind}.json")
    if os.path.exists(path):
        module.load(path)
        logger.info("Loaded compiled %s module from %s", kind, path)
    else:
        logger.info("No compiled %s artifact; using seed instructions.", kind)
    return module


def build_extraction_module(config: Config):
    return _build("extraction", config)


def build_linking_module(config: Config):
    return _build("linking", config)


def build_enrichment_module(config: Config):
    return _build("enrichment", config)
