"""
dspy_agents.py
==============
DSPy-backed implementations of the three reasoning agents. They expose the SAME
methods as the prompt-based agents (process / process_corpus), reuse the same
chunking, models, and ontology, and emit the same internal objects — so the
pipeline can switch engines by config alone (`agent_engine="dspy"`).

The difference is entirely in how the LLM call is made: a compiled DSPy module
instead of a hand-written forced-tool-use prompt.
"""

from __future__ import annotations

import logging
from collections import OrderedDict
from typing import List

from .chunking import chunk_text
from .config import Config
from .dspy_modules import build_enrichment_module, build_extraction_module, build_linking_module
from .models import (
    Chunk,
    Claim,
    Concept,
    ConceptLink,
    Document,
    DocumentExtraction,
    Enrichment,
    Entity,
    Relationship,
)
from .ontology import FrameworkOntology

logger = logging.getLogger("avatar2.dspy_agents")


def _dedupe(items):
    seen = OrderedDict()
    for it in items:
        seen.setdefault(it.id, it)
    return list(seen.values())


class DSPyExtractionAgent:
    def __init__(self, config: Config | None = None, ontology: FrameworkOntology | None = None):
        self.config = config or Config()
        self.ontology = ontology
        self._scaffold = ""
        if ontology and self.config.ontology_guided_extraction:
            self._scaffold = ontology.scaffold_for_prompt(self.config.extraction_scaffold_limit)
        self.module = build_extraction_module(self.config)

    def process(self, document: Document) -> DocumentExtraction:
        spans = chunk_text(document.text, self.config.chunk_size, self.config.chunk_overlap)
        chunks: List[Chunk] = []
        for i, (text, start, end) in enumerate(spans):
            pred = self.module(
                document_title=document.title, ontology_scaffold=self._scaffold, chunk=text
            )
            r = pred.result
            chunks.append(
                Chunk(
                    id=f"{document.id}::chunk_{i:04d}",
                    document_id=document.id,
                    document_title=document.title,
                    sequence=i,
                    text=text,
                    char_start=start,
                    char_end=end,
                    entities=_dedupe([Entity.from_raw(e) for e in r.entities]),
                    concepts=_dedupe([Concept.from_raw(c) for c in r.concepts]),
                    relationships=[Relationship.from_raw(x) for x in r.relationships],
                    claims=[Claim.from_raw(c) for c in r.claims],
                )
            )
        return DocumentExtraction(
            document_id=document.id, title=document.title, source_path=document.source_path, chunks=chunks
        )

    def process_corpus(self, documents: List[Document]) -> List[DocumentExtraction]:
        return [self.process(d) for d in documents]


class DSPyMiningAgent:
    """Framework linking via DSPy; cross-doc + provenance reuse the deterministic agent."""

    def __init__(self, config: Config | None = None, ontology: FrameworkOntology | None = None):
        cfg = config or Config()
        self.config = cfg
        self.ontology = ontology or FrameworkOntology.from_json(cfg.framework_ontology_path)
        self.module = build_linking_module(cfg)
        # delegate the deterministic parts to the prompt-based agent
        from .relationship_mining_agent import RelationshipMiningAgent

        self._det = RelationshipMiningAgent(cfg, ontology=self.ontology)

    def process(self, extractions, use_llm_linking: bool = True):
        chunks = [c for ex in extractions for c in ex.chunks]
        for chunk in chunks:
            links = {}
            for token in [e.name for e in chunk.entities] + [c.label for c in chunk.concepts]:
                fc = self.ontology.match_alias(token)
                if fc:
                    links[fc.id] = ConceptLink(
                        framework_concept_id=fc.id, framework_label=fc.label,
                        framework_iri=fc.iri, relation="mentions", confidence=0.9, evidence=token,
                    )
            if use_llm_linking:
                pred = self.module(ontology_catalog=self.ontology.catalog_for_prompt(), chunk=chunk.text)
                for raw in pred.result.links:
                    fc = self.ontology.get(raw.framework_concept_id)
                    if fc:
                        prev = links[fc.id].confidence if fc.id in links else 0.0
                        links[fc.id] = ConceptLink(
                            framework_concept_id=fc.id, framework_label=fc.label,
                            framework_iri=fc.iri, relation=raw.relation,
                            confidence=max(raw.confidence, prev), evidence=raw.evidence,
                        )
            for concept in chunk.concepts:
                fc = self.ontology.match_alias(concept.label)
                if fc:
                    concept.ontology_iri = fc.iri
            chunk.framework_links = list(links.values())

        cross = self._det._cross_document_links(chunks)
        prov = self._det._provenance_chains(chunks)
        from .models import MiningResult

        return MiningResult(
            cross_document_links=cross, provenance_chains=prov,
            linked_chunk_count=sum(1 for c in chunks if c.framework_links),
        )


class DSPyEnrichmentAgent:
    def __init__(self, config: Config | None = None, ontology: FrameworkOntology | None = None):
        cfg = config or Config()
        self.config = cfg
        self.ontology = ontology or FrameworkOntology.from_json(cfg.framework_ontology_path)
        self.module = build_enrichment_module(cfg)

    def process(self, extractions):
        for ex in extractions:
            for chunk in ex.chunks:
                pred = self.module(
                    document_title=chunk.document_title,
                    chunk=chunk.text,
                    known_concepts=", ".join(c.label for c in chunk.concepts) or "(none)",
                    known_frameworks=", ".join(fl.framework_label for fl in chunk.framework_links) or "(none)",
                )
                r = pred.result
                chunk.enrichment = Enrichment(
                    summary=r.summary, keywords=r.keywords, topics=r.topics,
                    audience_level=r.audience_level, audience_rationale=r.audience_rationale,
                    semantic_tags=r.semantic_tags,
                    related_concepts=[lbl for fl in chunk.framework_links
                                      for lbl in self.ontology.related_of(fl.framework_concept_id)],
                )
        return extractions
